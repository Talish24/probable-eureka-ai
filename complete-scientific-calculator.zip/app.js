class AdvancedScientificCalculator {
    constructor() {
        // Wait for DOM to be fully loaded before initialization
        this.initializeBasicCalculator();
        this.initializeTabSwitching();
        this.initializeCalculusFeatures();
        this.initializeMatrixFeatures();
        this.initializeSolverFeatures();
    }

    initializeBasicCalculator() {
        // Basic calculator elements
        this.display = document.getElementById('display');
        this.history = document.getElementById('history');
        this.angleMode = document.getElementById('angleMode');
        this.errorMessage = document.getElementById('errorMessage');
        
        // Basic calculator state
        this.currentInput = '0';
        this.previousInput = '';
        this.operator = null;
        this.waitingForOperand = false;
        this.memory = 0;
        this.isDegreeMode = true;
        this.secondFunction = false;
        this.lastResult = 0;
        
        this.initializeEventListeners();
        this.updateDisplay();
    }

    initializeEventListeners() {
        // Basic calculator button events
        document.querySelectorAll('#basic-tab .btn').forEach(button => {
            button.addEventListener('click', (e) => {
                e.preventDefault();
                this.handleButtonPress(e.target);
            });
        });

        // Keyboard events
        document.addEventListener('keydown', (e) => {
            this.handleKeyPress(e);
        });

        // Create memory indicator
        const displaySection = document.querySelector('.display-section');
        if (displaySection && !document.getElementById('memoryIndicator')) {
            const memoryIndicator = document.createElement('div');
            memoryIndicator.className = 'memory-indicator';
            memoryIndicator.id = 'memoryIndicator';
            memoryIndicator.textContent = 'M';
            displaySection.appendChild(memoryIndicator);
        }
    }

    initializeTabSwitching() {
        const tabButtons = document.querySelectorAll('.tab-btn');
        const tabContents = document.querySelectorAll('.tab-content');

        tabButtons.forEach(button => {
            button.addEventListener('click', (e) => {
                e.preventDefault();
                const targetTab = button.dataset.tab;
                
                // Update tab buttons
                tabButtons.forEach(btn => btn.classList.remove('active'));
                button.classList.add('active');
                
                // Update tab contents
                tabContents.forEach(content => content.classList.remove('active'));
                const targetContent = document.getElementById(`${targetTab}-tab`);
                if (targetContent) {
                    targetContent.classList.add('active');
                }
                
                // If switching to matrix tab, ensure grid is generated
                if (targetTab === 'matrix') {
                    setTimeout(() => this.generateMatrixGrid(), 100);
                }
            });
        });
    }

    initializeCalculusFeatures() {
        const derivativeBtn = document.getElementById('calculate-derivative');
        const integralBtn = document.getElementById('calculate-integral');

        if (derivativeBtn) {
            derivativeBtn.addEventListener('click', (e) => {
                e.preventDefault();
                this.calculateDerivative();
            });
        }

        if (integralBtn) {
            integralBtn.addEventListener('click', (e) => {
                e.preventDefault();
                this.calculateIntegral();
            });
        }
    }

    initializeMatrixFeatures() {
        const matrixSize = document.getElementById('matrix-size');
        const determinantBtn = document.getElementById('calculate-determinant');
        const transposeBtn = document.getElementById('calculate-transpose');
        const inverseBtn = document.getElementById('calculate-inverse');
        const clearMatrixBtn = document.getElementById('clear-matrix');

        if (matrixSize) {
            matrixSize.addEventListener('change', () => {
                this.generateMatrixGrid();
            });
        }

        if (determinantBtn) {
            determinantBtn.addEventListener('click', (e) => {
                e.preventDefault();
                this.calculateDeterminant();
            });
        }

        if (transposeBtn) {
            transposeBtn.addEventListener('click', (e) => {
                e.preventDefault();
                this.calculateTranspose();
            });
        }

        if (inverseBtn) {
            inverseBtn.addEventListener('click', (e) => {
                e.preventDefault();
                this.calculateInverse();
            });
        }

        if (clearMatrixBtn) {
            clearMatrixBtn.addEventListener('click', (e) => {
                e.preventDefault();
                this.clearMatrix();
            });
        }

        // Initialize with 2x2 matrix
        setTimeout(() => this.generateMatrixGrid(), 100);
    }

    initializeSolverFeatures() {
        const quadraticBtn = document.getElementById('solve-quadratic');
        const cubicBtn = document.getElementById('solve-cubic');

        if (quadraticBtn) {
            quadraticBtn.addEventListener('click', (e) => {
                e.preventDefault();
                this.solveQuadratic();
            });
        }

        if (cubicBtn) {
            cubicBtn.addEventListener('click', (e) => {
                e.preventDefault();
                this.solveCubic();
            });
        }
    }

    // Basic Calculator Functions
    handleButtonPress(button) {
        this.addPressAnimation(button);
        this.hideError();

        const action = button.dataset.action;
        const value = button.dataset.value;

        if (value !== undefined) {
            this.inputNumber(value);
        } else if (action) {
            this.handleAction(action);
        }
    }

    handleAction(action) {
        switch (action) {
            case 'add':
            case 'subtract':
            case 'multiply':
            case 'divide':
                this.handleOperator(action);
                break;
            case 'equals':
                this.calculate();
                break;
            case 'ac':
                this.allClear();
                break;
            case 'backspace':
                this.backspace();
                break;
            case 'decimal':
                this.inputDecimal();
                break;
            case 'percent':
                this.handlePercent();
                break;
            case 'sin':
            case 'cos':
            case 'tan':
                this.handleTrigFunction(action);
                break;
            case 'ln':
            case 'log':
                this.handleLogFunction(action);
                break;
            case 'sqrt':
                this.handleSqrt();
                break;
            case 'square':
                this.handleSquare();
                break;
            case 'power':
                this.handleOperator('power');
                break;
            case 'exp':
                this.handleExp();
                break;
            case 'factorial':
                this.handleFactorial();
                break;
            case 'pi':
                this.inputConstant(Math.PI);
                break;
            case 'e':
                this.inputConstant(Math.E);
                break;
            case 'open-paren':
                this.inputOperator('(');
                break;
            case 'close-paren':
                this.inputOperator(')');
                break;
            case 'deg-rad':
                this.toggleAngleMode();
                break;
            case '2nd':
                this.toggleSecondFunction();
                break;
            case 'mc':
                this.memoryClear();
                break;
            case 'mr':
                this.memoryRecall();
                break;
            case 'm+':
                this.memoryAdd();
                break;
            case 'm-':
                this.memorySubtract();
                break;
        }
    }

    inputNumber(num) {
        if (this.waitingForOperand) {
            this.currentInput = num;
            this.waitingForOperand = false;
        } else {
            this.currentInput = this.currentInput === '0' ? num : this.currentInput + num;
        }
        this.updateDisplay();
    }

    inputDecimal() {
        if (this.waitingForOperand) {
            this.currentInput = '0.';
            this.waitingForOperand = false;
        } else if (this.currentInput.indexOf('.') === -1) {
            this.currentInput += '.';
        }
        this.updateDisplay();
    }

    inputOperator(nextOperator) {
        this.currentInput += nextOperator;
        this.updateDisplay();
    }

    inputConstant(value) {
        if (this.waitingForOperand) {
            this.currentInput = value.toString();
            this.waitingForOperand = false;
        } else {
            this.currentInput = value.toString();
        }
        this.updateDisplay();
    }

    handleOperator(nextOperator) {
        const inputValue = parseFloat(this.currentInput);

        if (this.previousInput === '') {
            this.previousInput = inputValue;
        } else if (this.operator) {
            const currentValue = this.previousInput || 0;
            const newValue = this.performCalculation(this.operator, currentValue, inputValue);

            if (newValue === null) return;

            this.currentInput = String(newValue);
            this.previousInput = newValue;
        }

        this.waitingForOperand = true;
        this.operator = nextOperator;
        this.updateHistory();
    }

    calculate() {
        try {
            if (this.currentInput.includes('(') || this.currentInput.includes(')')) {
                const result = this.evaluateExpression(this.currentInput);
                this.lastResult = result;
                this.currentInput = String(result);
                this.previousInput = '';
                this.operator = null;
                this.waitingForOperand = true;
            } else if (this.operator && this.previousInput !== '') {
                const inputValue = parseFloat(this.currentInput);
                const currentValue = this.previousInput;
                const newValue = this.performCalculation(this.operator, currentValue, inputValue);

                if (newValue === null) return;

                this.lastResult = newValue;
                this.currentInput = String(newValue);
                this.previousInput = '';
                this.operator = null;
                this.waitingForOperand = true;
            }
            this.updateHistory();
            this.updateDisplay();
        } catch (error) {
            this.showError('Error: Invalid expression');
        }
    }

    performCalculation(operator, firstOperand, secondOperand) {
        try {
            switch (operator) {
                case 'add':
                    return firstOperand + secondOperand;
                case 'subtract':
                    return firstOperand - secondOperand;
                case 'multiply':
                    return firstOperand * secondOperand;
                case 'divide':
                    if (secondOperand === 0) {
                        this.showError('Error: Division by zero');
                        return null;
                    }
                    return firstOperand / secondOperand;
                case 'power':
                    return Math.pow(firstOperand, secondOperand);
                default:
                    return secondOperand;
            }
        } catch (error) {
            this.showError('Error: Calculation error');
            return null;
        }
    }

    evaluateExpression(expression) {
        try {
            let expr = expression
                .replace(/×/g, '*')
                .replace(/÷/g, '/')
                .replace(/−/g, '-')
                .replace(/π/g, Math.PI)
                .replace(/e/g, Math.E);
            
            return Function('"use strict"; return (' + expr + ')')();
        } catch (error) {
            throw new Error('Invalid expression');
        }
    }

    // Calculus Functions
    calculateDerivative() {
        const functionStr = document.getElementById('derivative-function').value;
        const point = parseFloat(document.getElementById('derivative-point').value);
        const resultDiv = document.getElementById('derivative-result');

        try {
            if (!functionStr.trim()) {
                throw new Error('Please enter a function');
            }

            if (isNaN(point)) {
                throw new Error('Please enter a valid point');
            }

            const derivative = this.numericalDerivative(functionStr, point);
            resultDiv.className = 'result-display success';
            resultDiv.textContent = `d/dx [${functionStr}] at x = ${point}\nResult: ${derivative.toFixed(8)}\nMethod: Symmetric difference quotient with h = 0.0001`;
        } catch (error) {
            resultDiv.className = 'result-display error';
            resultDiv.textContent = `Error: ${error.message}`;
        }
    }

    calculateIntegral() {
        const functionStr = document.getElementById('integral-function').value;
        const lower = parseFloat(document.getElementById('integral-lower').value);
        const upper = parseFloat(document.getElementById('integral-upper').value);
        const resultDiv = document.getElementById('integral-result');

        try {
            if (!functionStr.trim()) {
                throw new Error('Please enter a function');
            }

            if (isNaN(lower) || isNaN(upper)) {
                throw new Error('Please enter valid bounds');
            }

            const integral = this.numericalIntegral(functionStr, lower, upper);
            resultDiv.className = 'result-display success';
            resultDiv.textContent = `∫ [${functionStr}] dx from ${lower} to ${upper}\nResult: ${integral.toFixed(8)}\nMethod: Simpson's Rule with 1000 intervals`;
        } catch (error) {
            resultDiv.className = 'result-display error';
            resultDiv.textContent = `Error: ${error.message}`;
        }
    }

    numericalDerivative(functionStr, x) {
        const h = 0.0001;
        const f = this.parseFunction(functionStr);
        return (f(x + h) - f(x - h)) / (2 * h);
    }

    numericalIntegral(functionStr, a, b) {
        const n = 1000; // Number of intervals
        const h = (b - a) / n;
        const f = this.parseFunction(functionStr);
        
        let sum = f(a) + f(b);
        
        for (let i = 1; i < n; i += 2) {
            sum += 4 * f(a + i * h);
        }
        
        for (let i = 2; i < n - 1; i += 2) {
            sum += 2 * f(a + i * h);
        }
        
        return (h / 3) * sum;
    }

    parseFunction(functionStr) {
        // Convert mathematical notation to JavaScript
        let jsFunction = functionStr
            .replace(/\^/g, '**')
            .replace(/sin\(/g, 'Math.sin(')
            .replace(/cos\(/g, 'Math.cos(')
            .replace(/tan\(/g, 'Math.tan(')
            .replace(/ln\(/g, 'Math.log(')
            .replace(/log\(/g, 'Math.log10(')
            .replace(/sqrt\(/g, 'Math.sqrt(')
            .replace(/exp\(/g, 'Math.exp(')
            .replace(/\be\b/g, 'Math.E')
            .replace(/\bpi\b/g, 'Math.PI')
            .replace(/π/g, 'Math.PI');

        return new Function('x', `"use strict"; return ${jsFunction}`);
    }

    // Matrix Functions
    generateMatrixGrid() {
        const size = parseInt(document.getElementById('matrix-size').value);
        const grid = document.getElementById('matrix-grid');
        
        if (!grid) return;
        
        grid.innerHTML = '';
        grid.className = `matrix-grid size-${size}`;
        
        for (let i = 0; i < size; i++) {
            for (let j = 0; j < size; j++) {
                const input = document.createElement('input');
                input.type = 'number';
                input.className = 'matrix-input';
                input.id = `matrix-${i}-${j}`;
                input.placeholder = '0';
                input.value = i === j ? '1' : '0'; // Identity matrix by default
                input.step = '0.1';
                grid.appendChild(input);
            }
        }
    }

    getMatrix() {
        const size = parseInt(document.getElementById('matrix-size').value);
        const matrix = [];
        
        for (let i = 0; i < size; i++) {
            matrix[i] = [];
            for (let j = 0; j < size; j++) {
                const element = document.getElementById(`matrix-${i}-${j}`);
                const value = element ? parseFloat(element.value) || 0 : 0;
                matrix[i][j] = value;
            }
        }
        
        return matrix;
    }

    calculateDeterminant() {
        const resultDiv = document.getElementById('matrix-result');
        
        try {
            const matrix = this.getMatrix();
            const det = this.determinant(matrix);
            
            resultDiv.className = 'result-display success';
            resultDiv.textContent = `Determinant: ${det.toFixed(8)}\n\nMatrix:\n${this.matrixToString(matrix)}`;
        } catch (error) {
            resultDiv.className = 'result-display error';
            resultDiv.textContent = `Error: ${error.message}`;
        }
    }

    calculateTranspose() {
        const resultDiv = document.getElementById('matrix-result');
        
        try {
            const matrix = this.getMatrix();
            const transpose = this.transpose(matrix);
            
            resultDiv.className = 'result-display success';
            resultDiv.textContent = `Transpose:\n${this.matrixToString(transpose)}\n\nOriginal:\n${this.matrixToString(matrix)}`;
        } catch (error) {
            resultDiv.className = 'result-display error';
            resultDiv.textContent = `Error: ${error.message}`;
        }
    }

    calculateInverse() {
        const resultDiv = document.getElementById('matrix-result');
        
        try {
            const matrix = this.getMatrix();
            const det = this.determinant(matrix);
            
            if (Math.abs(det) < 1e-10) {
                throw new Error('Matrix is singular (determinant = 0), inverse does not exist');
            }
            
            const inverse = this.inverse(matrix);
            
            resultDiv.className = 'result-display success';
            resultDiv.textContent = `Inverse:\n${this.matrixToString(inverse)}\n\nDeterminant: ${det.toFixed(8)}`;
        } catch (error) {
            resultDiv.className = 'result-display error';
            resultDiv.textContent = `Error: ${error.message}`;
        }
    }

    clearMatrix() {
        const size = parseInt(document.getElementById('matrix-size').value);
        
        for (let i = 0; i < size; i++) {
            for (let j = 0; j < size; j++) {
                const element = document.getElementById(`matrix-${i}-${j}`);
                if (element) {
                    element.value = '0';
                }
            }
        }
        
        const resultDiv = document.getElementById('matrix-result');
        if (resultDiv) {
            resultDiv.textContent = '';
            resultDiv.className = 'result-display';
        }
    }

    determinant(matrix) {
        const n = matrix.length;
        
        if (n === 1) {
            return matrix[0][0];
        }
        
        if (n === 2) {
            return matrix[0][0] * matrix[1][1] - matrix[0][1] * matrix[1][0];
        }
        
        let det = 0;
        for (let i = 0; i < n; i++) {
            const subMatrix = this.getSubMatrix(matrix, 0, i);
            det += Math.pow(-1, i) * matrix[0][i] * this.determinant(subMatrix);
        }
        
        return det;
    }

    getSubMatrix(matrix, row, col) {
        const n = matrix.length;
        const subMatrix = [];
        
        for (let i = 0; i < n; i++) {
            if (i === row) continue;
            const newRow = [];
            for (let j = 0; j < n; j++) {
                if (j === col) continue;
                newRow.push(matrix[i][j]);
            }
            subMatrix.push(newRow);
        }
        
        return subMatrix;
    }

    transpose(matrix) {
        const n = matrix.length;
        const result = [];
        
        for (let i = 0; i < n; i++) {
            result[i] = [];
            for (let j = 0; j < n; j++) {
                result[i][j] = matrix[j][i];
            }
        }
        
        return result;
    }

    inverse(matrix) {
        const n = matrix.length;
        const det = this.determinant(matrix);
        
        if (n === 2) {
            return [
                [matrix[1][1] / det, -matrix[0][1] / det],
                [-matrix[1][0] / det, matrix[0][0] / det]
            ];
        }
        
        const adjugate = [];
        for (let i = 0; i < n; i++) {
            adjugate[i] = [];
            for (let j = 0; j < n; j++) {
                const subMatrix = this.getSubMatrix(matrix, i, j);
                const cofactor = Math.pow(-1, i + j) * this.determinant(subMatrix);
                adjugate[j][i] = cofactor / det; // Note: j,i for transpose
            }
        }
        
        return adjugate;
    }

    matrixToString(matrix) {
        return matrix.map(row => 
            '[' + row.map(val => val.toFixed(4).padStart(8)).join(' ') + ']'
        ).join('\n');
    }

    // Solver Functions
    solveQuadratic() {
        const a = parseFloat(document.getElementById('quad-a').value) || 0;
        const b = parseFloat(document.getElementById('quad-b').value) || 0;
        const c = parseFloat(document.getElementById('quad-c').value) || 0;
        const resultDiv = document.getElementById('quadratic-result');

        try {
            if (a === 0) {
                if (b === 0) {
                    if (c === 0) {
                        throw new Error('Infinite solutions (0 = 0)');
                    } else {
                        throw new Error('No solution (inconsistent equation)');
                    }
                } else {
                    // Linear equation
                    const x = -c / b;
                    resultDiv.className = 'result-display success';
                    resultDiv.textContent = `Linear equation: ${b}x + ${c} = 0\nSolution: x = ${x.toFixed(8)}`;
                    return;
                }
            }

            const discriminant = b * b - 4 * a * c;
            
            resultDiv.className = 'result-display success';
            let result = `Quadratic: ${a}x² + ${b}x + ${c} = 0\nDiscriminant: ${discriminant.toFixed(8)}\n\n`;

            if (discriminant > 0) {
                const x1 = (-b + Math.sqrt(discriminant)) / (2 * a);
                const x2 = (-b - Math.sqrt(discriminant)) / (2 * a);
                result += `Two real roots:\nx₁ = ${x1.toFixed(8)}\nx₂ = ${x2.toFixed(8)}`;
            } else if (discriminant === 0) {
                const x = -b / (2 * a);
                result += `One repeated root:\nx = ${x.toFixed(8)}`;
            } else {
                const realPart = -b / (2 * a);
                const imagPart = Math.sqrt(-discriminant) / (2 * a);
                result += `Two complex roots:\nx₁ = ${realPart.toFixed(8)} + ${imagPart.toFixed(8)}i\nx₂ = ${realPart.toFixed(8)} - ${imagPart.toFixed(8)}i`;
            }

            resultDiv.textContent = result;
        } catch (error) {
            resultDiv.className = 'result-display error';
            resultDiv.textContent = `Error: ${error.message}`;
        }
    }

    solveCubic() {
        const a = parseFloat(document.getElementById('cubic-a').value) || 0;
        const b = parseFloat(document.getElementById('cubic-b').value) || 0;
        const c = parseFloat(document.getElementById('cubic-c').value) || 0;
        const d = parseFloat(document.getElementById('cubic-d').value) || 0;
        const resultDiv = document.getElementById('cubic-result');

        try {
            if (a === 0) {
                resultDiv.className = 'result-display error';
                resultDiv.textContent = 'Error: Not a cubic equation (coefficient a cannot be 0)';
                return;
            }

            const roots = this.solveCubicEquation(a, b, c, d);
            
            resultDiv.className = 'result-display success';
            let result = `Cubic: ${a}x³ + ${b}x² + ${c}x + ${d} = 0\n\nRoots:\n`;
            
            roots.forEach((root, index) => {
                if (typeof root === 'number') {
                    result += `x₃ = ${root.toFixed(8)}\n`;
                } else {
                    result += `x₃ = ${root.real.toFixed(8)} ${root.imag >= 0 ? '+' : ''}${root.imag.toFixed(8)}i\n`;
                }
            });

            resultDiv.textContent = result;
        } catch (error) {
            resultDiv.className = 'result-display error';
            resultDiv.textContent = `Error: ${error.message}`;
        }
    }

    solveCubicEquation(a, b, c, d) {
        // Normalize coefficients
        b /= a;
        c /= a;
        d /= a;

        // Calculate discriminant
        const p = c - (b * b) / 3;
        const q = (2 * b * b * b - 9 * b * c + 27 * d) / 27;
        const discriminant = (q * q) / 4 + (p * p * p) / 27;

        const roots = [];

        if (discriminant > 0) {
            // One real root, two complex roots
            const sqrt_disc = Math.sqrt(discriminant);
            const u = Math.cbrt(-q / 2 + sqrt_disc);
            const v = Math.cbrt(-q / 2 - sqrt_disc);
            
            const realRoot = u + v - b / 3;
            roots.push(realRoot);
            
            const realPart = -(u + v) / 2 - b / 3;
            const imagPart = Math.sqrt(3) * (u - v) / 2;
            
            roots.push({ real: realPart, imag: imagPart });
            roots.push({ real: realPart, imag: -imagPart });
        } else if (discriminant === 0) {
            // Multiple real roots
            if (q === 0) {
                // Three equal roots
                const root = -b / 3;
                roots.push(root, root, root);
            } else {
                // One single and one double root
                const u = Math.cbrt(-q / 2);
                roots.push(2 * u - b / 3);
                roots.push(-u - b / 3);
                roots.push(-u - b / 3);
            }
        } else {
            // Three distinct real roots
            const rho = Math.sqrt(-(p * p * p) / 27);
            const theta = Math.acos(-q / 2 * Math.sqrt(-27 / (p * p * p)));
            
            for (let k = 0; k < 3; k++) {
                const root = 2 * Math.cbrt(rho) * Math.cos((theta + 2 * Math.PI * k) / 3) - b / 3;
                roots.push(root);
            }
        }

        return roots;
    }

    // Helper functions for trigonometric and other operations
    handleTrigFunction(func) {
        try {
            const value = parseFloat(this.currentInput);
            let angle = value;

            if (this.isDegreeMode) {
                angle = value * (Math.PI / 180);
            }

            let result;
            switch (func) {
                case 'sin':
                    result = this.secondFunction ? Math.asin(value) : Math.sin(angle);
                    break;
                case 'cos':
                    result = this.secondFunction ? Math.acos(value) : Math.cos(angle);
                    break;
                case 'tan':
                    result = this.secondFunction ? Math.atan(value) : Math.tan(angle);
                    break;
            }

            if (this.secondFunction && this.isDegreeMode) {
                result = result * (180 / Math.PI);
            }

            this.currentInput = String(result);
            this.waitingForOperand = true;
            this.secondFunction = false;
            this.updateSecondFunctionUI();
            this.updateDisplay();
        } catch (error) {
            this.showError('Error: Invalid input for trigonometric function');
        }
    }

    handleLogFunction(func) {
        try {
            const value = parseFloat(this.currentInput);
            if (value <= 0) {
                this.showError('Error: Logarithm of non-positive number');
                return;
            }

            let result;
            switch (func) {
                case 'ln':
                    result = this.secondFunction ? Math.exp(value) : Math.log(value);
                    break;
                case 'log':
                    result = this.secondFunction ? Math.pow(10, value) : Math.log10(value);
                    break;
            }

            this.currentInput = String(result);
            this.waitingForOperand = true;
            this.secondFunction = false;
            this.updateSecondFunctionUI();
            this.updateDisplay();
        } catch (error) {
            this.showError('Error: Invalid input for logarithmic function');
        }
    }

    handleSqrt() {
        try {
            const value = parseFloat(this.currentInput);
            if (value < 0) {
                this.showError('Error: Square root of negative number');
                return;
            }

            const result = this.secondFunction ? Math.pow(value, 2) : Math.sqrt(value);
            this.currentInput = String(result);
            this.waitingForOperand = true;
            this.secondFunction = false;
            this.updateSecondFunctionUI();
            this.updateDisplay();
        } catch (error) {
            this.showError('Error: Invalid input');
        }
    }

    handleSquare() {
        try {
            const value = parseFloat(this.currentInput);
            const result = this.secondFunction ? Math.cbrt(value) : Math.pow(value, 2);
            this.currentInput = String(result);
            this.waitingForOperand = true;
            this.secondFunction = false;
            this.updateSecondFunctionUI();
            this.updateDisplay();
        } catch (error) {
            this.showError('Error: Invalid input');
        }
    }

    handleExp() {
        try {
            const value = parseFloat(this.currentInput);
            const result = this.secondFunction ? Math.log(value) : Math.exp(value);
            this.currentInput = String(result);
            this.waitingForOperand = true;
            this.secondFunction = false;
            this.updateSecondFunctionUI();
            this.updateDisplay();
        } catch (error) {
            this.showError('Error: Invalid input');
        }
    }

    handleFactorial() {
        try {
            const value = parseInt(this.currentInput);
            if (value < 0 || !Number.isInteger(parseFloat(this.currentInput))) {
                this.showError('Error: Factorial requires non-negative integer');
                return;
            }
            if (value > 170) {
                this.showError('Error: Number too large for factorial');
                return;
            }

            let result = 1;
            for (let i = 2; i <= value; i++) {
                result *= i;
            }

            this.currentInput = String(result);
            this.waitingForOperand = true;
            this.updateDisplay();
        } catch (error) {
            this.showError('Error: Invalid input for factorial');
        }
    }

    handlePercent() {
        try {
            const value = parseFloat(this.currentInput);
            this.currentInput = String(value / 100);
            this.waitingForOperand = true;
            this.updateDisplay();
        } catch (error) {
            this.showError('Error: Invalid input');
        }
    }

    toggleAngleMode() {
        this.isDegreeMode = !this.isDegreeMode;
        this.angleMode.textContent = this.isDegreeMode ? 'DEG' : 'RAD';
        
        const degRadButton = document.querySelector('[data-action="deg-rad"]');
        if (degRadButton) {
            degRadButton.textContent = this.isDegreeMode ? 'DEG' : 'RAD';
        }
    }

    toggleSecondFunction() {
        this.secondFunction = !this.secondFunction;
        this.updateSecondFunctionUI();
    }

    updateSecondFunctionUI() {
        const functionButtons = document.querySelectorAll('.btn-function');
        functionButtons.forEach(button => {
            if (this.secondFunction) {
                button.classList.add('second-active');
            } else {
                button.classList.remove('second-active');
            }
        });

        const secondButton = document.querySelector('[data-action="2nd"]');
        if (secondButton) {
            if (this.secondFunction) {
                secondButton.classList.add('btn-active');
            } else {
                secondButton.classList.remove('btn-active');
            }
        }
    }

    memoryClear() {
        this.memory = 0;
        this.updateMemoryIndicator();
    }

    memoryRecall() {
        this.currentInput = String(this.memory);
        this.waitingForOperand = true;
        this.updateDisplay();
    }

    memoryAdd() {
        this.memory += parseFloat(this.currentInput) || 0;
        this.updateMemoryIndicator();
    }

    memorySubtract() {
        this.memory -= parseFloat(this.currentInput) || 0;
        this.updateMemoryIndicator();
    }

    updateMemoryIndicator() {
        const indicator = document.getElementById('memoryIndicator');
        if (indicator) {
            if (this.memory !== 0) {
                indicator.classList.add('show');
            } else {
                indicator.classList.remove('show');
            }
        }
    }

    allClear() {
        this.currentInput = '0';
        this.previousInput = '';
        this.operator = null;
        this.waitingForOperand = false;
        this.hideError();
        this.updateDisplay();
        this.updateHistory();
    }

    backspace() {
        if (this.currentInput.length > 1) {
            this.currentInput = this.currentInput.slice(0, -1);
        } else {
            this.currentInput = '0';
        }
        this.updateDisplay();
    }

    updateDisplay() {
        if (this.display) {
            this.display.textContent = this.formatNumber(this.currentInput);
        }
    }

    updateHistory() {
        if (this.history) {
            if (this.operator && this.previousInput !== '') {
                const operatorSymbol = this.getOperatorSymbol(this.operator);
                this.history.textContent = `${this.formatNumber(this.previousInput)} ${operatorSymbol}`;
            } else {
                this.history.textContent = '';
            }
        }
    }

    getOperatorSymbol(operator) {
        switch (operator) {
            case 'add': return '+';
            case 'subtract': return '−';
            case 'multiply': return '×';
            case 'divide': return '÷';
            case 'power': return '^';
            default: return '';
        }
    }

    formatNumber(num) {
        const number = parseFloat(num);
        if (isNaN(number)) return num;
        
        if (Math.abs(number) >= 1e10 || (Math.abs(number) < 1e-6 && number !== 0)) {
            return number.toExponential(6);
        }
        
        return number.toString();
    }

    showError(message) {
        if (this.errorMessage) {
            this.errorMessage.textContent = message;
            this.errorMessage.classList.add('show');
            setTimeout(() => {
                this.hideError();
            }, 3000);
        }
    }

    hideError() {
        if (this.errorMessage) {
            this.errorMessage.classList.remove('show');
        }
    }

    addPressAnimation(button) {
        button.classList.add('pressed');
        setTimeout(() => {
            button.classList.remove('pressed');
        }, 150);
    }

    handleKeyPress(event) {
        const key = event.key;
        
        // Only handle keys when in basic calculator tab
        const activeTab = document.querySelector('.tab-btn.active');
        if (!activeTab || activeTab.dataset.tab !== 'basic') {
            return;
        }
        
        if (key >= '0' && key <= '9') {
            this.inputNumber(key);
        } else if (key === '.') {
            this.inputDecimal();
        } else if (key === '+') {
            this.handleOperator('add');
        } else if (key === '-') {
            this.handleOperator('subtract');
        } else if (key === '*') {
            this.handleOperator('multiply');
        } else if (key === '/') {
            event.preventDefault();
            this.handleOperator('divide');
        } else if (key === '=' || key === 'Enter') {
            event.preventDefault();
            this.calculate();
        } else if (key === 'Escape') {
            this.allClear();
        } else if (key === 'Backspace') {
            this.backspace();
        } else if (key === '(') {
            this.inputOperator('(');
        } else if (key === ')') {
            this.inputOperator(')');
        }
    }
}

// Initialize calculator when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    new AdvancedScientificCalculator();
});